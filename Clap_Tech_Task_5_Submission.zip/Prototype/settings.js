function setDifftoEasy() {
  window.sessionStorage.setItem("diff", "easy");
}
function setDifftoNormal() {
  window.sessionStorage.setItem("diff", "normal");
}
function setDifftoHard() {
  window.sessionStorage.setItem("diff", "hard");
}
function setDifftoHardcore() {
  window.sessionStorage.setItem("diff", "hardcore");
}
function setDifftoPermaDeath() {
  window.sessionStorage.setItem("diff", "permadeath");
}
function unleashTheBeast() {
  window.sessionStorage.setItem("Beast", "Yes");
}
function trapTheBeast() {
  window.sessionStorage.setItem("Beast", "No");
}
